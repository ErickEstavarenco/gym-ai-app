import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, User as UserIcon, Loader2, Sparkles } from 'lucide-react';
import { chatBubble, fadeUp, staggerParent } from '../../lib/motion';
import Badge from '../ui/Badge';
import { PersonalTrainerAvatar } from '../ui';
import { resolveSuggestionIcon } from '../../services/coachLogic';

/**
 * ChatPanel — shared chat body used by both full-screen Chat page
 * and the floating ChatBot widget. Header is supplied externally.
 */
const ChatPanel = ({
  messages,
  onSend,
  loading = false,
  onSuggestionClick,
  inputPlaceholder = 'Digite sua mensagem...',
  showSuggestions = true,
}) => {
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e) => {
    e?.preventDefault?.();
    const value = inputValue.trim();
    if (!value || loading) return;
    onSend(value);
    setInputValue('');
  };

  const handleChipClick = (suggestion) => {
    // Sugestões podem ser:
    //   { label, action, kind, icon } — shape novo (coachLogic)
    //   { label, icon } — shape antigo (string icon direto)
    const action = suggestion.action || suggestion.label;
    const kind = suggestion.kind || (suggestion.icon ? 'text' : 'text');
    onSuggestionClick?.(action, kind, suggestion);
  };

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* Messages */}
      <motion.div
        variants={staggerParent(0.05)}
        initial="hidden"
        animate="show"
        className="flex-1 overflow-y-auto px-4 py-4 space-y-4 scrollbar-thin"
      >
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              variants={chatBubble}
              initial="hidden"
              animate="show"
              exit={{ opacity: 0 }}
              className={`flex gap-2.5 ${message.type === 'user' ? 'flex-row-reverse' : ''}`}
            >
              {message.type === 'bot' ? (
                <PersonalTrainerAvatar size="sm" className="flex-shrink-0" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-gym-surface-elevated border border-gym-line flex items-center justify-center flex-shrink-0">
                  <UserIcon size={14} className="text-gym-text-primary" />
                </div>
              )}

              <div className={`max-w-[78%] space-y-2 ${message.type === 'user' ? 'items-end' : ''}`}>
                <div
                  className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                    message.type === 'bot'
                      ? 'bg-gym-surface border border-gym-line text-gym-text-primary'
                      : 'bg-gradient-to-br from-gym-accent to-gym-accent-hover text-white shadow-glow-sm'
                  }`}
                >
                  <div className="whitespace-pre-line">{message.content}</div>
                </div>

                {showSuggestions && message.suggestions && message.suggestions.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {message.suggestions.map((s, idx) => {
                      const Icon = resolveSuggestionIcon(s.icon);
                      const isRetry = s.action === 'retry' || s.kind === 'retry';
                      return (
                        <button
                          key={s.id || idx}
                          type="button"
                          onClick={() => handleChipClick(s)}
                          disabled={loading}
                          className={`group inline-flex items-center gap-1.5 px-3 py-1.5 border rounded-full text-xs transition-all duration-200 disabled:opacity-50 ${
                            isRetry
                              ? 'bg-gym-warning/10 border-gym-warning/30 text-gym-warning hover:bg-gym-warning/20 hover:border-gym-warning/60'
                              : 'bg-gym-surface border-gym-line text-gym-text-secondary hover:border-gym-accent/50 hover:text-gym-text-primary hover:bg-gym-accent-muted'
                          }`}
                        >
                          <Icon size={12} className={isRetry ? 'text-gym-warning' : 'text-gym-accent'} />
                          <span>{s.label}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {loading && (
          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate="show"
            className="flex gap-2.5"
          >
            <PersonalTrainerAvatar size="sm" className="flex-shrink-0" />
            <div className="bg-gym-surface border border-gym-line px-4 py-3 rounded-2xl flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-gym-accent rounded-full animate-bounce" />
              <span
                className="w-1.5 h-1.5 bg-gym-accent rounded-full animate-bounce"
                style={{ animationDelay: '0.15s' }}
              />
              <span
                className="w-1.5 h-1.5 bg-gym-accent rounded-full animate-bounce"
                style={{ animationDelay: '0.3s' }}
              />
            </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </motion.div>

      {/* Input */}
      <form
        onSubmit={handleSubmit}
        className="p-4 border-t border-gym-line bg-gym-bg/80 backdrop-blur-xl"
      >
        <div className="relative flex items-center gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            disabled={loading}
            placeholder={inputPlaceholder}
            className="flex-1 bg-gym-surface border border-gym-line rounded-2xl pl-4 pr-12 py-3 text-sm text-gym-text-primary placeholder:text-gym-text-muted focus:outline-none focus:border-gym-accent focus:shadow-glow-sm transition-all duration-200 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={!inputValue.trim() || loading}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-xl bg-gradient-to-br from-gym-accent to-gym-accent-hover text-white flex items-center justify-center shadow-glow-sm hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed disabled:shadow-none transition-all"
          >
            {loading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
          </button>
        </div>
        <p className="text-[10px] text-gym-text-muted text-center mt-2 flex items-center justify-center gap-1">
          <Sparkles size={10} className="text-gym-accent" />
          Powered by Gym AI
        </p>
      </form>
    </div>
  );
};

export default ChatPanel;